# 현재 디렉터리 및 하위 디렉터리에서 모든 .git 디렉터리를 찾음
$gitDirs = Get-ChildItem -Recurse -Directory -Force -Filter ".git"

foreach ($gitDir in $gitDirs) {
    $repoPath = $gitDir.FullName
    $workTreePath = Split-Path $repoPath -Parent
    Write-Output "Updating repository at $workTreePath"
    git --git-dir=$repoPath --work-tree=$workTreePath pull
}
